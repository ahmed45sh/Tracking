const Loader = () => {
return (
    <div className=" transition-all duration-300 w-screen h-screen flex justify-center items-center bg-gradient-to-b from-[#020B27] to-blue-500">
<span className="loader"></span>

    </div>
)
}
 export default Loader